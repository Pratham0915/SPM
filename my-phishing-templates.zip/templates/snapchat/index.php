<?php
// Placeholder for snapchat phishing page
?>