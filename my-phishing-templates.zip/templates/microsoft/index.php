<?php
// Placeholder for microsoft phishing page
?>