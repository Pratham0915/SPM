<?php
// Placeholder for ebay phishing page
?>