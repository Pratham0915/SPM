<?php
// Placeholder for pinterest phishing page
?>