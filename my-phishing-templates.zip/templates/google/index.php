<?php
// Placeholder for google phishing page
?>