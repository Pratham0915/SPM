<?php
// Placeholder for badoo phishing page
?>