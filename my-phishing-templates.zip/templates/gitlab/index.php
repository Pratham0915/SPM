<?php
// Placeholder for gitlab phishing page
?>