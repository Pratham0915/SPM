<?php
// Placeholder for instagram phishing page
?>