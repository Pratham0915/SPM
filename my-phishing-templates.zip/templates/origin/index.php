<?php
// Placeholder for origin phishing page
?>