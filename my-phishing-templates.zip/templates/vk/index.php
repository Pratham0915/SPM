<?php
// Placeholder for vk phishing page
?>