<?php
// Placeholder for twitter phishing page
?>