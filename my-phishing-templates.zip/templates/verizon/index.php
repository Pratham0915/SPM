<?php
// Placeholder for verizon phishing page
?>