<?php
// Placeholder for wifi phishing page
?>