<?php
// Placeholder for linkedin phishing page
?>