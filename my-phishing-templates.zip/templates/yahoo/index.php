<?php
// Placeholder for yahoo phishing page
?>