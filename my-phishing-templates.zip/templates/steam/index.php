<?php
// Placeholder for steam phishing page
?>