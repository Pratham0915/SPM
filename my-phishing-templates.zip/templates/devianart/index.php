<?php
// Placeholder for devianart phishing page
?>