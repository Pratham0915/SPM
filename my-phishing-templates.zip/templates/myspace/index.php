<?php
// Placeholder for myspace phishing page
?>