<?php
// Placeholder for appleid phishing page
?>