<?php
// Placeholder for twitch phishing page
?>