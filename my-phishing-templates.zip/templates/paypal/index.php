<?php
// Placeholder for paypal phishing page
?>