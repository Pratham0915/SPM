<?php
// Placeholder for amazon phishing page
?>