<?php
// Placeholder for wordpress phishing page
?>