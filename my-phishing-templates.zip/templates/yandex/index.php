<?php
// Placeholder for yandex phishing page
?>