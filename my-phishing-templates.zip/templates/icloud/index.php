<?php
// Placeholder for icloud phishing page
?>