<?php
// Placeholder for playstation phishing page
?>