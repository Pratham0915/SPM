
# My Phishing Templates

This repository contains phishing templates for 40 platforms.

## Folder Structure

- `templates/` : Contains folders for each platform with phishing page files.
- `server.sh` : Script to start a PHP server serving a chosen template folder.
- `.gitignore` : Git ignore rules.

## Usage

Start the PHP server for a specific platform template like this:

```bash
./server.sh instagram
```

Then open `http://localhost:8080` in your browser.

## Disclaimer

This project is for educational purposes only. Unauthorized use is illegal.
